import React from "react";
import Nav from "./components/Nav";
import Carousel from "./components/Carousel";
import Items from "./Items";
function Home(){
    return(
        <>
        <Nav/>
        <Carousel/>
        <Items/>

        
        </>
    );
}
export default Home;