import React, { useState, useEffect } from "react";
import axios from "axios";



function ItemsDesc() {
    const [itemDesc, setItemDesc] = useState([])
    useEffect(() => {
        axios.get("https://fakestoreapi.com/products")
            .then((response) => {
                setItemDesc(response.data)
            })
    }, [])
    return (
        <div>
            {itemDesc.map((data) => {
                return (
                    <div className="Desc" data-aos="zoom-in">
                    <img src={data.image} />
                    <h6 >{data.title}</h6>
                    <h5 >₹{data.price}</h5>
                    <p >{data.description}</p>
                    </div>
                )
            })}
        </div>
    );
}
export default ItemsDesc;