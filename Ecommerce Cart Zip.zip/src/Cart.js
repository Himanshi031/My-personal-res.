import PriceDetails from './components/PriceDetails';
import ProductList from './components/ProductList';
import React, { useState } from 'react';
import Nav from './components/Nav';
import PaymentGateway from './components/PaymentGateway';

function Cart() {

    const products = [
        {
            price: 150999,
            img: 'img/image1.webp',
            brand: "iphone 14 pro",
            quantity: 0
        },
        {
            price: 90999,
            img: 'img/image4.webp',
            brand: "iphone 13 ",
            quantity: 0
        },
        {
            price: 15999,
            img: 'img/image3.jpg',
            brand: "Motorola one power",
            quantity: 0
        },
        {
            price: 50999,
            img: 'img/image2.jpg',
            brand: "Samsung Galaxy S6",
            quantity: 0
        }
    ]

    let [productlist, setProductList] = useState(products);
    let [totalAmount, setTotalAmount] = useState(0);

    const increQuantity = (index) => {
        let newProductList = [...productlist];
        let newTotalAmount = totalAmount;
        newProductList[index].quantity++;
        newTotalAmount += newProductList[index].price;
        setProductList(newProductList);
        setTotalAmount(newTotalAmount);
        console.log();
    }

    const decreQuantity = (index) => {
        let newProductList = [...productlist];
        let newTotalAmount = totalAmount;
        if (newProductList[index].quantity > 0) {
            newProductList[index].quantity--;
            newTotalAmount -= newProductList[index].price;
        }
        setTotalAmount(newTotalAmount);
        setProductList(newProductList);
    }

    return (
        <>
            <Nav/>
            <ProductList productList={productlist}
                increQuantity={increQuantity}
                decreQuantity={decreQuantity} />
            <PriceDetails totalAmount={totalAmount} />
        </>

    );
}
export default Cart;