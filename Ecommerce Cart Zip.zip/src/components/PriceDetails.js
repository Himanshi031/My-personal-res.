import React from "react";
// import PaymentGateway from "./PaymentGateway";
// import {Routes, Route} from 'react-router-dom';
import { useNavigate } from "react-router-dom";
// import PaymentGateway from "./PaymentGateway";


function PriceDetails(props) {
    const navigate = useNavigate();
    function handleClick() {
        navigate('/PaymentGateway');
      }

    return (
        <>
            <h3>Price Details</h3>
            <div className="row fixed-bottom">
                <button type="button" className="btn btn-danger col-2" >Reset</button>
                <div className="col-8 bg-dark text-white text-align-center">
                    ₹{props.totalAmount}
                </div>
                <button className="btn btn-primary col-2" onClick={handleClick}>Pay Now</button>

                {/* <Routes>
                    <Route path="/PaymentGateway" element={<PaymentGateway />} />
                </Routes> */}
            </div>
        </>
    );
}
export default PriceDetails;
