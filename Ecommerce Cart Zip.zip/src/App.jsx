import './App.css';
// import Nav from './components/Nav';
// import PriceDetails from './components/PriceDetails';
// import ProductList from './components/ProductList';
// import React, { useState } from 'react';
import { Routes, Route, BrowserRouter } from 'react-router-dom';
import Home from './Home';
import Cart from './Cart';
import Wishlist from './components/Wishlist';
import ItemsDesc from './ItemsDesc';
import PaymentGateway from './components/PaymentGateway';
// import Product from './components/Product';


function App() {

  


  return (
    <div className='App'>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Cart" element={<Cart />} />
          <Route path='/PaymentGateway' element={<PaymentGateway/>} />
          <Route path='/Wishlist' element={<Wishlist/>} />
          <Route path='/ItemsDesc' element= {<ItemsDesc/>} />
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
