import React, { useState, useEffect } from "react";
import axios from 'axios';
import Wishlist from "./components/Wishlist";
// import ItemsDesc from "./ItemsDesc";
import { useNavigate } from "react-router-dom";
import AOS from 'aos';
import 'aos/dist/aos.css';
// import Cart from "./Cart";

function Items() {
    const [itemsData, setItemsData] = useState([]);
    useEffect(() => {
        axios.get("https://fakestoreapi.com/products")
            .then((response) => {
                setItemsData(response.data)
            })
    }, [])
    const navigate = useNavigate();
    function toItemDesc(){
        navigate('/ItemsDesc');
    }
    function toCart(){
        navigate('/Cart');
    }
    useEffect(() => {
        AOS.init();
      }, [])

    return (
        <div  className="Items container text-center">
            <h3>Shop Now</h3>
            <hr/>
            <div class="row row-cols-3">
            {itemsData.map((data) => {
                return (<div className="Itemscontent">
                        
                    <div className="Item col" data-aos="zoom-in">
                        <img src={data.image} onClick={toItemDesc}/>
                        <h6 onClick={toItemDesc}>{data.title}</h6>
                        <h5>₹{data.price}</h5>
                        <button className="btn1 mx-2 bg-primary text-white" onClick={toCart}>Add To Cart</button><span><button className="btn1 mx-2 bg-danger text-white" onClick={Wishlist}>Wishlist</button></span>
                    </div>
                </div>
                )
            })}
        </div>
        </div>
    );
}
export default Items;