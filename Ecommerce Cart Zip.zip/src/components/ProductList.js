import React from "react";
import Product from './Product';

function ProductList(props){
    return(
        
        props.productList.map((product, i) => {
            return <Product product={product} key={i} increQuantity={props.increQuantity} decreQuantity={props.decreQuantity} index={i} />
        })
        
    );
}
export default ProductList;