import React from "react";

function Wishlist(props){
    return(
        <div>
            
        </div>
    );
}
export default Wishlist;