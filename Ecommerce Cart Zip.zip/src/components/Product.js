import React from "react";
import './App.css';

function Product(props) {

    

    return (
        <div className="Cart row container" data-aos="fade-right">
            <div className="col-5 d-flex">
                <img src={props.product.img} alt="img" />
                <div className="wat">
                <h2>{props.product.brand}</h2>
                <h4>₹{props.product.price}</h4>
                </div>
                
            </div>
            <div className="col-4">
            <div className="btn-group" role="group" aria-label="Basic outlined example">
                    <button type="button" className="btn btn-outline-dark" onClick={() => {props.decreQuantity(props.index)}}>
                        -
                    </button>
                    <button type="button" className="btn btn-outline-dark" >
                        {props.product.quantity}
                    </button>
                    <button type="button" className="btn btn-outline-dark" onClick={() => {props.increQuantity(props.index)}}>
                        +
                    </button>
                </div>
            </div>
            <div className="col-3">
                <h5>₹{props.product.quantity * props.product.price}</h5>
            </div>  
    </div>
    );
}
export default Product;